export default function Contact() {
    return (
      <div>
        <h2>NAMA            : HILWA ISNAINI MARFUAH</h2>
        <h2>TTL             : KAB.SEMARANG, 15 MARET 2004</h2>
        <h2>PELATIHAN       : REACT</h2>
        <h2>NAMA INSTRUKTUR : RIRI TRIANA</h2>
        </div>
    );
}