export default function Home() {
    return (
      <div>
        <h1>
        Selamat datang di dunia sinema kami!
        </h1>
        <h1>Temukan kisah-kisah tak terlupakan dan nikmati pengalaman menonton yang menghibur di sini.
        </h1>
        </div>
    );
}